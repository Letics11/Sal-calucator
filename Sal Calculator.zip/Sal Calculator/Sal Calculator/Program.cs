﻿using System;

namespace Sal_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("**********Employee Salary***********");
            // the data will be entered

            Console.Write("Enter No of Employees");
            int n = Convert.ToInt32(Console.ReadLine());

            //data will be stored in the array sali 
            salary[] sali = new salary[n];

            for (int i = 0; i < n; i++) {
                sali[i]=new salary();
                Console.Write("Employee ID:{0}",i+1);

                Console.Write("Employee Name:");
                sali[i].Name = Console.ReadLine();

                Console.Write("Enter Month:");
                sali[i].Month = Console.ReadLine();

                Console.Write("Enter Year:");
                sali[i].Year = Console.ReadLine();

                Console.Write("Enter Basic Salary");
                sali[i].Basic_SA = Convert.ToDouble(Console.ReadLine());

                sali[i].Rent = sali[i] * (60/100);
                sali[i].Medic = sali[i] * .35;
                sali[i].Conv = sali[i] * .10;

                sali[i].Gross_SA = sali[i].Rent + sali[i].Medic + sali[i].Conv;
                sali[i].Net_SA = sali[i].Basic_SA + sali[i].Gross_SA;

            }

            Console.WriteLine("Employee ID\tEmp Name\tMonth\tYear\tBasic Salary\tRent\tMedical\tConveyance\tGross Salary\tNet-Salary");
            Console.Write("******************************************************************************************************************");
            //data will be printed out here:

            for (int i=0; i<n; i++) {
                Console.Write("\t{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}",i=1, 
                    sali[i].Name, sali[i].Month, sali[i].Year, sali[i].Basic_SA, sali[i].Rent, sali[i].Medic, sali[i].Conv, sali[i].Gross_SA, sali[i].Net_SA);
            }
            Console.ReadLine();
           
        }
        // the class is for the getters and setters of for the data beigng entered. the code will be run in the main method. 
        class salary {
            public string Name { get; set; }

            public string Month { get; set; }

            public string Year { get; set; }

            public double Basic_SA { get; set; }
            public double Rent { get; set; }
            public double Medic { get; set; }
            public double Conv { get; set; }
            public double Net_SA { get; set; }
            public double Gross_SA { get; set; }



        }
    }
}
